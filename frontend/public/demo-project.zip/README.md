# Demo Codebase
This is a standard demo project containing a client frontend, an Express REST API router, a business logic controllers layer, a database model layer, and a service layer.
Use it to test CodeMap visualizer!
