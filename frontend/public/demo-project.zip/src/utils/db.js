const mongoose = require('mongoose');

exports.connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/demo-db');
    console.log('MongoDB database connected successfully');
  } catch (err) {
    console.error('Database connection failed:', err.message);
  }
};
