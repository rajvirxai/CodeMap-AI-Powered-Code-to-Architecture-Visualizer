const express = require('express');
const cors = require('cors');
const userRoutes = require('./routes/userRoutes');
const { connectDB } = require('./utils/db');

const app = express();
app.use(cors());
app.use(express.json());

connectDB();

app.use('/api/users', userRoutes);

app.listen(8080, () => {
  console.log('App running on port 8080');
});
