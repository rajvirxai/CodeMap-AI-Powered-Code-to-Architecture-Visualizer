import React, { useEffect, useState } from 'react';
import { fetchUserData } from '../services/api';
import Button from './Button';

export default function UserProfile({ userId }) {
  const [user, setUser] = useState(null);

  useEffect(() => {
    fetchUserData(userId).then(data => setUser(data));
  }, [userId]);

  if (!user) return <div>Loading Profile...</div>;

  return (
    <div className="p-4 border rounded shadow">
      <h2>{user.name}</h2>
      <p>{user.email}</p>
      <Button label="Refresh Profile" onClick={() => window.location.reload()} />
    </div>
  );
}
